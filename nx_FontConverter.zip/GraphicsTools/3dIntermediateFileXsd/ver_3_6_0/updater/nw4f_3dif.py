﻿#----------------------------------------------------------------------------
# Project:  NintendoWare
#
# Copyright (C)Nintendo All rights reserved.
#
# These coded instructions, statements, and computer programs contain proprietary
# information of Nintendo and/or its licensed developers and are protected by
# national and international copyright laws. They may not be disclosed to third
# parties or copied or duplicated in any form, in whole or in part, without the
# prior written consent of Nintendo.
#
# The content herein is highly confidential and should be handled accordingly.
#----------------------------------------------------------------------------

# 中間ファイルの更新、System.Xml.XmlDocument 型の doc を更新します
def Update(doc):
	# fsd 以外の <nw4f_3dif> version を 3.7.0 に変更します。
	if doc.SelectSingleNode("/nw4f_3dif/shader_definition"):
		print("\nIntermediateFileUpdater does not support updating shader definition(.fsdb) file. Please recreate it by 3dShaderConverter.\n")
		Result = False
		return
	version = doc.SelectSingleNode("/nw4f_3dif/@version")
	version.Value = "3.7.0"
